This patch can be used on top of
- regular USA rom  [MD5: A00012533E76649F4E7E1B7AA5A9EE07]
- vivify93 text cleanup 1.5+



Version 0.1
- Hold B button when moving to toggle faster, slower.
  When let go, player will continue to move at this speed.

- Overworld map now allows fast movement.
