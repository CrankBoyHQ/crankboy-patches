A patch for Galaga & Galaxian (E) [S][!].gb to make it work with the gameboy color.

The patch also probably works with the other versions of Galaga & Galaxian.gb, but you will need to fix the headers afterwards.

This hack includes:

* Colors for both games on the gameboy color
* Still works with regular and super gameboy

2022/01/25 v1.0
2022/01/26 v1.1
 - Add more galaxian colors. 
 - Fix DMG and SuperGameboy graphics bugs