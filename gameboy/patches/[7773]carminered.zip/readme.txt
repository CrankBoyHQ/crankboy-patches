Use a BPS patcher to patch carminered-1.1.bps over a unmodified copy of english pokemon red.

To play, any regular GB emulator will work. I reccomend yo use une with SGB support for the color experience

Alternatively, you can download the github repository from the release's page, follow the install.md instructions and build the romhack youself, I only recommend this method if you have build pokemon roms from PRET before.

Github repository link:
https://github.com/wrulfy/carminered

Link to the latest release:
https://github.com/wrulfy/carminered/releases/latest

Detailed list of features:
https://github.com/wrulfy/carminered/wiki/List-of-features

All the documentation you would need is in the github wiki:
https://github.com/wrulfy/carminered/wiki