A quick and dirty rom hack for Jonathan H, to let him play gargoyles quest in double speed mode on the gameboy color.

I've made a bunch of different versions of the hack, with different palette options. 

Pick one, and apply against the ue version of gargoyles quest to play.

The ones labeled OriginalGbc have vrey saturated colors, to show up best on the original gbc screen (or other original type screens).

If you are playing on a replacement screen, or an emulator, try using one of the ips files with New in the filename.

If you are unhappy with all of the choices, I've included all the 
asm files, and the map file showing where all my changes are in rom
so you can create your own palettes and recompile.

WARNING

There are a few issues due to the conversion, mostly sprite layering issues (like the dog enemy that throws his head has his head and body flipping between being on top).

