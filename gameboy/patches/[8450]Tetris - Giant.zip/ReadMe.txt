Tetris - Giant was really just made as a proof of concept.  Making sprites this large in this engine was no easy task.

The playfield being so cramped makes the gameplay extremely challenging so a Tetris - Giant - EZ version is also included.  It uses the same concept as Tetris - Beginner and ends up being very fun.

This mod is for the more common 1.1 version of Gameboy Tetris.

Two player mode simply cannot handle these sprites and is more or less broken.  The piece preview window doesn't like the size of these sprites either... you will have to just remember the pattern on the blocks.

It is recommended that you keep your "pit" on the left side of the screen because when you spin the extremely long "I" piece, it favors the left side.


Thanks to Bavi_H for helping fix a glitch in Game Boy Tetris and for helping me determine how Height is handled in mode B.