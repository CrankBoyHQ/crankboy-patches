Wizardry Empire - Fukkatsu no Tsue (Japan)


Version: 0.3




Empire1 had a bloody, gory version of the Ghoul monster.

Wizardry experts mention that it was toned down (censored)
for the Japan-only Empire2 release.

This patch puts back the Empire1 graphics into the game.





update 0.2
Correct standalone patch for Japan version




update 0.3
Recensor patch added.

Readme corrections






Original Japan game can be used with:
- Bug fixes 0.1+
- Ghoul uncensor 0.2+

Can be applied in any order.






Not compatible:
- (*1) English translation  (uncensor already included)





(*1)

If you prefer the original Empire2 Ghoul, then it's okay
to apply the recensor.ips patch
