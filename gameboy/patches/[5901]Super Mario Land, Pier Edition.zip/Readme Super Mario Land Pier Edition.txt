Super Mario Land, Pier Edition
------------------
Version 1.0 - 16/04/2021
Pier

------------------
Français

"Super Mario Land, Pier Edition" est un hack qui modifie l'intégralité des 12 niveaux de Super Mario Land.
Découvrez Sarasaland d'une nouvelle manière avec une toute nouvelle dispositiondes éléments du jeu original (pouvant donner un résultat très différent du niveau de base).
Une fois le jeu terminé pour la première fois, vous pourrez y tester votre talent avec le mode difficile. Des ennemis supplémentaires apparaîtront (et souvent au bon endroit pour vous mettre en difficulté).

De plus, certains sprites ont été modifiés:
  - Le nom du jeu sur l'écran titre évidemment.
  - Mario n'a pas de casquette (ni de casque sur son avion) quand il est petit (comme dans 3D Land / 3D World).
  - À l'inverse, Daisy possède une couronne désormais.
  - Les Champignons, Fleurs Super Boule et Étoiles ont des yeux.
  - Les Super Boules ressemblent un peu plus à leur apparition dans Super Mario Maker 2.
  - Les balles tirées par l'avion de Mario sont légérement différentes.
  - Certains ennemis ont été modifiés pour ressembler un peu plus à leur artwork (Chibibo, Gira, Pionpi, le boss Hiyoihoi, etc...).

J'ai utilisé la rom "Super Mario Land (World).gb" comme base pour créer le patch mais vous pouvez l'appliquez sur des roms légérement différentes (comme une traduction... Si vous en avez besoin).

------------------
English

"Super Mario Land, Pier Edition" is a hack that change the 12 levels of Super Mario Land.
Discover Sarasaland with a totally new placement of the original game elements (even to give an very different result than the base level). 
When the game is finished for the first time, you can test your skills with the hard mode. Additional ennemy will appear (and mostly at the right spot to put you in a difficult position).

Futhermore, some sprites has been changed:
  - The name of the game on the title screen of course.
  - Mario is hatless (or helmetless on his plane) when he is small (like 3D Land / 3D World).
  - On the contrary, Daisy have a crown now.
  - Mushrooms, Super Ball Flowers and Stars have eyes.
  - Super Balls look like more their appareance in Super Mario Maker 2.
  - Mario plane bullets are slightly differents.
  - Some ennemies has been changed to look more like their artwork (Chibibo, Gira, Pionpi, the boss  Hiyoihoi, etc...).

I used the rom "Super Mario Land (World).gb" to create the patch but you can apply the patch on slightly different roms (like an translation... If you need).