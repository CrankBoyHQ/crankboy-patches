

 __         __         _              ____
 \ \       / /        | |            / __ \
  \ \  _  / /         | |           |_/ / /
   \ \/W\/ /          |L|__            /2/__
    \_/-\_/  A R I O  |____| A N D    /_____|

                   Revision B

            Polished and Uncensored


Added Left out detail from original release;
Mainly the Restoration of Arched Windows 
Fixed most Leftover pixels from that version
Also added a few leftover beta features, 
all around more Beer and Sushi for everyone! 

Here are the features:
(Note there may be things I forgot to mention, this continues lol)

*Update as of version 2.2, various minor changes to enemies' sprite and palettes; see below
Noted original and new changes I made to enemies.

**NEW
Fixed Wario's frames, Smoother animations; Fixed Wario's Victory Pose, Missed Wario end game cutscene tile, Updated to be consistent with other updated poses; walking, plus removed white pixels in his arm in those scenes. Colored all "Foot and toe" shading to be the same color, for consistency.

Updated walking frames, Fixed some pixels in fat Wario's glove in his "landing" frame, also well as original leg shading
Additionally fixed mid-frame of the swimming animation-- All frames have been updated for most forms, status effect or not.
Note all changes are hand drawn, not based on WL3 or others rendentions

*Update as of version 2.1, *SPOILER The first level of the Uncanny Mansion, 
light has been added INSIDE the Pelican door with the four ghost, for convenience.*
Addtionally, Fixed some pixels on Wario's face and arm in "Owl Wario" state.
Also found a couple windows I missed in Wario's castle

*Update as of version 2.0 all levels with underwater doors now are dark blue appropiate to the palette of water to each individual level, AND the underwater coins in lvl alt 3_2 are now the right color, making all underwater coins consistent. Also fixed Bobo in this update, no more flashing pixels of the wrong color.Also the falling rocks now are colored naturally to their environment.

[Also note that if you change the name of your copy of Warioland 2 to match your .sav file you shouldn't lose progress with the updates]

Added Mud Blocks https://tcrf.net/Wario_Land_II#Sticky_Block

Added Green Jug generator and re-colored jug
https://tcrf.net/Wario_Land_II#Jugs

Added Wario's eye to the title from the Japanese release(Patch Rev B 1.2)

Restored Arched Windows-(Done); Added 3 missing pixels to the rounded window top graphic asset.
Fixed Wall in lvl 5_2 ;)
Edited ShyGuyXXL's Wario pic- Give credit
Fixed Wario's forms palettes
Fixed Coin icon on all subscreens to match
Custom tiles for added detail where needed
Match game now reflects new "Punch"
Added "Gameboy Treasure" as the "reward" for the Match game tutorial

Enemies have been updated for version 2.2 release

Added in lost KamuKamu from original release
Added Beer Penguin
Fixed Rooster; Had transparent "hole" of 4 pixels in the torso filled in
Fixed Alarm clock; Mix of original and color updated versions
Fixed Pirate Goom; fixed many pixels to be more accurate
Fixed Helmet Dude "Punch"; Redrawn very slightly, better animation
Fixed Hammer Ape; minor pixel consistency, colored the handle in "stunned" state
Fixed Iron Ball Monkey; When throwing right, no longer has a pixel shift out of place 
Fixed Pelican; fixed miss colored pixels
Fixed Window Pirate "GuaGua"; changed bottle to white outline & red label/cap
Fixed Turtle; fixed pixels in the legs for better animation, Now a dark green
Fixed Owl; Redrawn to be reminicent of the monochrome version
Fixed Cave Master; redrew the lower half of the stomach to actually have animation
Fixed Bobo; no more flashing pixels of the wrong color
Fixed pixels in Dangerous Ducks' Neck; His bandanas' now tail animates
"The Four Ducks" and now Bright Burnt orange and Blue.
Syrup's "Beetle Gooms'" now have a paler palette.

Palette changes to certain sprites where needed to better suit there look

(Modified Peguin to better suit the English version's OAM; basically how tiles are placed and when)



Things I'd still like to do:

Find where the Palette for the Title screen is stored,(Not so easily done), and change
the Red on the Roman numerial two and the Castle to Purple,like the Japanese version, and use with the Wario Eye graphic title screen.

Find a way to modifify the Pause Screen to ONLY disable movement,
not foreground sprites, like the Original Monochrome version handles it.