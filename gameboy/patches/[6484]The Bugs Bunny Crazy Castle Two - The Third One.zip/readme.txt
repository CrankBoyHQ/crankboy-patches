The Ultimate Bugs Bunny Crazy Castle Two: The Third One, by Mallory P. Maggiore, 2022

Version 1.0

The Bugs Bunny Crazy Castle II hack, Game Boy

Created January 7, 2012

Contact: golden_road15@hotmail.com