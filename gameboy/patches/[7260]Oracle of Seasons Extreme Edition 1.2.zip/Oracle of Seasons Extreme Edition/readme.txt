--- IMPORTANT TO KNOW ABOUT THIS HACK ---

THIS IS MY FIRST HACK, IT DOES NOT HAVE THE BEST QUALITY!
IT'S MADE TO BE DIFFICULT BUT FUN.

READ BELOW FOR IMPORTANT INFO:

This hack is not made for secrets.

This game is also not made to be "impossible" for newer players, but a lot of things are really difficult at D4 and
above, so use of savestates might be wise if you feel uncomfortable with the rise in difficulty. 

Sometimes the game decides to swap seasons in a place it isn't supposed to, which ends up breaking certain things..
I've tried to fix this the best I can but it's not always as stable as it should be. (Should be fully fixed as of 1.2)


If you didn't guess it already, it's also very hard. Though difficulty really just starts at D4+

The overworld used to be changed in different ways too, espescially in Temple Ruins and Subrosia. But due to bugs caused
by editing Subrosia, I made the OW and Subrosia vanilla. Although there is a small change in Temple Ruins still...

All dungeons are the same as in vanilla, however, they may use:
Different songs and different color palettes. 
They are also more difficult of course, and every Essence Room has a tiny challenge that concludes what the entire
dungeon had as it's main challenge (most of the time).



HACK MADE BY: @DORRIEDD at Twitter | Flufe at Speedrun.com 

