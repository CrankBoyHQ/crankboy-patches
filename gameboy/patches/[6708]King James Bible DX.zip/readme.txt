KING JAMES BIBLE DX
A Game Boy colorization hack by kkzero

Read the Bible...in color.
Search the Bible...in color.
Match words from the Bible...in color.
Guess words from the Bible...in color.

COMPATIBILITY:
This game has dodgy compatibility with emulators/hardware, due to it using the unlicensed Wisdom Tree mapper.
BGB will run it perfectly.
Emulicious, Sameboy, and mGBA have issues with locking up/resetting.
An Everdrive GB X7 will lock up on the Bible and Sheperd, and run the Word Match with glitchy text.
The Gameboy 2MB WT Mapper Flash Cart has not been tested at the time of writing.

CHANGELOG

v1.0 - 2022-04-01: Initial release.

Q: Why does this hack exist?
A: IDK I just remembered that this game existed a few months back and thought "Hey I should make a DX hack of it for April Fools Day"