Pokémon Gen 6 Typing
Release Number 0
by dewhi100

This patch adds the Steel, Dark, and Fairy types to Pokémon Red/Blue.

Files included in this distribution:
Readme.rtf		…	This file
steel-dark-upgrade	…	Notes I made while hacking
gen6Typing.ups		…	The actual patch

Changes made to the original game:

	Move types have been updated to gen 6:
		Bite is now dark type.
		Gust is now flying type.
		Karate Chop is now fighting type.
		Sand Attack is now ground type.

	Pokémon types have been updated to gen 6:
		Magnemite/Magneton are now electric/steel type.
		Clefairy/Clefable are now pure fairy type.
		Jigglypuff/Wigglytuff are now normal/fairy type.
		Mr. Mime is now psychic/fairy type.

	Gen 6 weaknesses/resistances/immunities.
		E.g. ghost vs. psychic has been fixed, etc.
		Includes steel, dark, and fairy.

	Possible bugs.
		This is my first hack.
		I may have accidentally broken some code in the process of creating it. 
		It is virtually untested.
 		(Gust hit bulbasaur super-effectively and I said, "good enough for me".)
		Feedback is welcome, however I can't guarantee a fix for any bugs. :( 

This patch was made with MultiPatch, on Mac OS 10.7. Enjoy!
-demzo