- Change the character face of Towers -

"Towers - characters change.ips"

Apply this patch to the headerless ROM of GBC "Towers - Lord Baniff's Deceit".

[Changes]
- Changed main character graphics
- Renamed 2 characters
