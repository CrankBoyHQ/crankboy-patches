This is a graphics mod for Game Boy Tetris called "Tetris - 1984". This attempts to reproduce the look of the original version of Tetris which was made for the Electronika 60.

Original Game Boy games technically only have these 4 "colors": white, light grey, dark grey, and black.  Therefore this mod just uses white on black instead of the Electronika's traditional green on black display.

Though, interestingly, if you play this mod on the original Game Boy it will appear green on black since that system had a green tint.   Also, you can potentially use whatever device you are playing on to change white to green.

----

All game modes, even 2 player, have been edited and tested.

This mod is for the more common 1.1 version of Game Boy Tetris.

_______


I previously never included a donation link in my mods ReadMe files; but recently I found someone selling one of my mods online on a physical cartridge!  So if anyone really enjoys this game, and has a bit of money to spare, please send some my way: paypal.me/33thirtythree33