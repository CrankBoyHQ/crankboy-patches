04/05/13 v1.1 update:

Following dialogues shortened and/or modified:

Guardian Acorn
Piece of Power
Last Golden Leaf
The Genie
Yoshi Doll
Keyhole rock
Songless Ocarina
Fourth Piece of Heart
Seashell Mansion spirit
Beakless owl statues
Nearby Camera Shop sign
NPC Camera Shop mentioner
Camera Shop message on map
One of Level 2 owl statues (four bat room)
One of Level 7 owl statues (Three Of A Kind enemy room)
Two of overworld owl statues (phone booth in mountains & rapids waterfall)

The name 'Papahl' can be accessed if you meet him above before you
have the pineapple. This is fixed.

Title screen is modified.

Blocks and chests in the five treasure chest room are rearranged.

Power Bracelet can be used to access the fishing pond if you so choose.

Eliminated unnecessary time sinks in Levels 3, 4, and to the 
lesser extent, 6.

In Level 3, the gel is replaced with something else in the conveyor 
room. It was flawed because the sword can make contact with 
the gel through the block when it jumps.

Fixed one of the rooms in Level 5, one of the blocks wasn't supposed
to be pushable. That's the room before the third encounter with the 
Master Stalfos.

Access to Magic Powder in Level 6 is added.

- - -

For any feedback you can reach me at jeville42135@gmail.com