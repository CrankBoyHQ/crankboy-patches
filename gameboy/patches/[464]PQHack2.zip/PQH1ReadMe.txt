                          Lazy Power Quest 


A hack of: Power_Quest_(U)_(M6)_[C][!].gbc
Hacked By: Me_Dave
Graphics By: Nintendo Of Japan

Changes in version 1.1 Axe Model has been altered too. Repainted it in two days. And my arm hurts.   


In Version 1.0
 
I got tired of playing the same old Power Quest all the time looking at the same robot models over and over and over 
again. This patch fixes it to have the robot graphics from the japanese gameboy no color version but take note this is still
a game boy color game. Some of it looks cool and some of it looks not as good as before but at least it is different. That is
the point. All models are changed except for the Axe model witch is the same in both versions I would repaint him too but it 
would take two weeks and I am lazy. You can call this the lazy version it will probably be rejected anyway even though it 
is an improvement of the original game. Anyway I hope they add it I am sure others would enjoy it too, Also the mother and 
the best friend in the game among a few other people are different too. From the japanese version which is different. Enjoy.


Special Thanks Go To
Nintendo Of Japan.


To use the patch you need an Ips Patcher I use Luner IPS.
This Patch Power_Quest_Hack_(ver1.1)_(U)_(M6)_[C][!].ips
The original rom  Power_Quest_(U)_(M6)_[C][!].gbc

  
 