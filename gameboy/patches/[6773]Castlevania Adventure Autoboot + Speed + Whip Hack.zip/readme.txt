Konami GB Collection Vol. 1 (Europe)
CRC32: 203F8727

Patch Version: 1.0

This is an autoboot patch for Castlevania Adventure included in the Konami GB Collection WITH the speed and whip hack from hiro1112 but WITHOUT the graphical changes. Note that the autoboot patch from dACE differs in this regard.

- Autoboot into Castlevania Adventure
- Increased character speed
- No whip downgrade when being hit by an enemy

Credits to tidi, hiro1112 and Ugetab.
