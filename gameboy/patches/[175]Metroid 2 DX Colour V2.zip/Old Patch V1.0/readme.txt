Metroid 2 Color Patch IPS

This file was originally posted at Metroid Evolution (http://metroid.homestead.com). If you got it from somewhere else, then just be sure to pay Metroid Evolution a visit!

To use this file you'll need an IPS patcher program and a Metroid 2 ROM. Then just follow the instructions of your program to apply the IPS patch to the Metroid 2 ROM.

This file is based on a modified version of an original color scheme by Dan Davis, and was created using the Game Boy Colorizer (http://www.geocities.com/blind_tom2001/) and SamIPS (http://go.to/loongsam).