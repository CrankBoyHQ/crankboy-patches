I fixed a bunch of stuff and made it so this hack runs on the real hardware.  Spikeman fixed all the difficult stuff I couldn't
figure out.  This patch runs start to finish on the real hardware without and major issues.

2013 Drakon

The_Domo@hotmail.com