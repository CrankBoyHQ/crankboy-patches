A big overhaul of Bomb Jack for the gameboy.

Adding colors, fixes and improvements.

This hack includes:

* Colors everywhere
* Added an info screen on game start, since most videos on youtube people stuggled with the controls
* High score table now saves
* New flashier graphics for Level, bonus and game over screens
* Still plays on DMG
* Removed continue after gameover

Apply to "Bomb Jack (Europe).gb" md5sum = 7615154dc9afb1a7d7d2fe63b76c68e4

Credits
Zombie101 - GBC instructions screen graphics
MojoDodo - Everything else

History
2022/04/25 v1.0

