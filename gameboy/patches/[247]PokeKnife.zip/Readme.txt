Pokemon Knife Patch 1.0

This is a simple (and a lil buggy) hack that allows the main character 
to kill people on the original pokemon red or blue from game boy.

basically it enables a knife like stuff to appear when you press select, and when 
someone is in the path,it disappears.

notes:
- this patch WONT work on FireRed or LeafGreen,or even other roms like pokemon green,yellow,
gold,silver,crystal,and wont work also on the japanese versions of red and blue,only the usa and
probably europe versions

- when you change the scene,the people will come back to life,as i'm lazy and did
not implemented a system to save the dead on the cartridge.

- sometimes my scene changing detection evil scheme also fails miserably,so, you also
may need to enter and goes out of some buildings :3

- some people can�t be killed because they're "props" pretending to be people,
this includes oak aides,the guy sat on the pokemon center,and the police officer on 
the front of the house in cerulean.

- do not kill people that will walk,this make em "walk forever" and the game locks up
if you really want to skip a trainer battle,kill him,and walk where he was before.

- this specially applies to the fossil nerd,to pass that part without fighting the nerd
kill a fossil instead of picking it

- you unfortunaly can�t kill the guys at the victory road too,but nothing stops you from
mauling a certain drunk,and a certain guide :3

credits:
Z80a,coding,art(this is why look cheesy).

special thanks:
nintendo for doing this game,and giving me a lot of space to play with on the rom
zophar.net for the docs
and gbcolorizer for the font of inspiration
