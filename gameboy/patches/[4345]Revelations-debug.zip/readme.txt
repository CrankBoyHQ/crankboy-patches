Revelations: The Demon Slayer (GBC)
Debug menu patch

by Revenant (d@revenant1.net)
for The Cutting Room Floor (tcrf.net)
-------------------------------------

This patch is designed to restore some debugging functionality which is present
in release versions of the game, but was made inaccessible. 

To use it, apply either of the patches to the respective version of the game,
and then press Start during normal gameplay to access the debug menu.
Only the Game Boy Color enhanced versions of the game are supported.

For a more detailed explanation of the stuff this patch enables, check out:
https://tcrf.net/Revelations:_The_Demon_Slayer

Compatible files
----------------

These patches are compatible with the following versions of the game:

Revelations - The Demon Slayer (U) [C][!].gbc
MD5 before: 86ED74283FE0071F8D3F05923051EFAB
MD5 after:  CAE82323F2F219DE920D08F01B7C99A5

Megami Tensei Gaiden - Last Bible (J) [C][!].gbc
MD5 before: 9F4382352A6FD43C844C3ACED7CD842A
MD5 after:  7BF8EE698F7E8448BB42482E4D165999
