Seiken Densetsu is the first game in the Mana series. However, upon localization, the title
was changed to Final Fantasy Adventure in North America, and Mystic Quest in Europe. On top 
of this, there was some minor censorship done to the game. This hack aims to restore the 
English localization back to the original title, with censors removed. Therefore, all 
regional changes to the graphics except for the HUD have been reverted.

Included are both an IPS patch and a BPS patch; each are identical in function, so which 
one to use relies solely on personal preference. 


ROM Information
	No-Intro Name: Final Fantasy Adventure (USA)
	(No-Intro version  20130802-061634)
	ROM/File SHA-1: 8B93C55EE2660C60CF86DD70058F96ACE98782C8
	Patched ROM/File SHA-1: E24EB4A11E553B9FB085570E03C855C5532D68CD