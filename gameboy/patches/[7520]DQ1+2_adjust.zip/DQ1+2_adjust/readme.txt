- Dragon Quest 1+2 adjustment -

"DQ1+2_adjust.ips"

Apply this patch to the headerless ROM of GBC "Dragon Quest 1+2".

[Changes]
- Change the graphics of the main characters
- MP consumption halved
- Monster weakening
- Increase in experience points and money received
- Adjusted the equipment that the main characters can use
  (*Princess Moon can use a hammer, etc.)

Note)
Use it after understanding that it will be a very easy game.
