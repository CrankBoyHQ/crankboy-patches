Megami Tensei Gaiden: Last Bible II (GBC)
Debug menu patch

by Revenant (d@revenant1.net)
for The Cutting Room Floor (tcrf.net)
-------------------------------------

This patch is designed to restore some debugging functionality which is present
in the Game Boy Color version of the game, but was made inaccessible. 

To use it, apply the patch and then press Start during normal gameplay to access
the debug menu. Only the Game Boy Color enhanced version of the game is supported.

For a more detailed explanation of the stuff this patch enables, check out:
https://tcrf.net/Megami_Tensei_Gaiden:_Last_Bible_II

Compatible files
----------------

These patches are compatible with the following versions of the game:

Megami Tensei Gaiden - Last Bible II (J) [C][!].gbc
MD5 before: 7E32DC8B60413CFAA24F941691E545D2
MD5 after:  EA9A7881D925CA3159B1D41F779510EC
