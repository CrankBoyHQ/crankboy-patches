 .=========================.
( FLYING DRAGON GAIDEN HACK )
 '========================='

Here's an attempt to make Fighting Simulator 2 in 1 how it should have been for the US release.

Version 1.00:

Staff:
FlashPV: Project leader, hacking, graphic editor
Omnizero: Original translation work (Gamefaqs)

ROM / ISO Information:
File Size 131072 ($20000)
ROM Size 131072 ($20000)
ROM SHA-1: 9073276D8ADF1E59829AE48073B42AE19C9770CE
ROM CRC32: 52678AE8
No-Intro ROM name: Fighting Simulator 2 in 1 (USA, Europe).gb
