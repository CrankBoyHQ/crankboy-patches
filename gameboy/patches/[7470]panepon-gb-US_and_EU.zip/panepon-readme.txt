Are you interested in playing the code-locked GB port of Panel de Pon, but not interested in entering long codes? Well this patch is just what you need!

Simply apply either the IPS *or* BPS patch (whichever one is easier for you to use) to your corresponding ROM. If you're patching
Pokemon Puzzle Challenge (USA).gbc
then get the patches from the "US" folder
and if you're patching
Pokemon Puzzle Challenge (Europe) (En,Fr,De,Es,It).gbc
then get the patches from the "EU" folder

This hack is effective for use on GB, GBC, and GBA systems.

Just for your information, here are the codes you would have had to do otherwise:

Cheat 1: If using a Game Boy Color / GB Advance / GB Player
At the title screen, press: "Up" 2 times, "Right" 4 times, Down, "Left" 10 times, "Up" 4 times, Right, "Down" 6 times, B.

Cheat 2: If using a Game Boy or Super Game Boy
At the "This game can only be played on the GBC" screen, press: "A" 24 times, then "B" 24 times.

if you have any questions, please PM me on the romhacking.net forums (username bankbank) or you can email me: bank [at] bankbank [dot] net

thank you!