=========================================================================================
About
=========================================================================================

This hack converts the original Pokemon Red/Blue into a GBC rom which applies the same colour palette the GBC applied when running the GB games. Pokemon Red has the red palette applied with sprites in green and Pokemon Blue has the blue palette applied with sprites in red. 

This hack is for those looking to have the original GBC palettes in emulators that only emulated Pokemon Red/Blue as Gameboy roms with no color.

This hack has taken code from the Pokemon Red Full Color Hack https://www.romhacking.net/hacks/1385/) and the colors were modified to match the GBC palette. Full credit given.

=========================================================================================
Patching
=========================================================================================

Apply the patch to a clean US rom of Pokemon Red or Blue, using Lunar IPS or something.


