Mega Man Xtreme 2 - Force GBC palettes
======================================

When played in GBA, Mega Man Xtreme 2 (and its japanese release Rockman X2: Soul Eraser)
uses brightened colors to compensate the GBA's darker screen.

This simple patch forces them to play with the default GBC palettes, even when played in GBA.

This is aimed mostly at GBA SP and GB Player users, so they can enjoy the game without
the over brightened palettes.


Enjoy.
Marc.


Patching information
--------------------
You must provide the original Mega Man Xtreme 2 or Rockman X2: Soul Eraser ROM:

Mega Man Xtreme 2 (USA, Europe)
CRC32: 8fedb6d8
MD5:   1f64989765f605d05cbd013e7ffcc352
SHA-1: cb1811ac8969f6b683df954b57138dd28ebb40ff

Rockman X2 - Soul Eraser (Japan)
CRC32: 17913dd0
MD5:   83f735d3357a32576516f6e20b5b7f19
SHA-1: b7308301706c5414bb75f33232042124d9a608f1

Apply the patch here: https://www.romhacking.net/patch/