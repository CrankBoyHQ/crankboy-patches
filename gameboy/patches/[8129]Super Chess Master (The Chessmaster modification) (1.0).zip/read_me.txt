SUPER CHESS MASTER (The Chessmaster modification) (1.0)
-------------------------------------------------------
Thanks for downloading Super Chess Master by Gumpy Function! Consider following him on instagram (@gumpyfunction) or itch.io for more Game Boy homebrew development or check out his website https://www.gumpyfunction.com/

INSTRUCTIONS:
-------------
First you will need to download the The Chessmaster ROM. Then you can patch the ROM using the online utility ROM Patcher JS by uploading both the original ROM and the .ips file within this .zip. Go to the links below to get the ROM and patch it.

Chessmaster, The (USA) (Rev 1).gb can be found at:
https://vimm.net/vault/3020

ROM Patcher JS:
https://www.romhacking.net/patch/