Pokemon - DX Violet

This hack is based on the Pokemon Red Full Color Hack by FroggestSpirit, Danny-E 33, IIMarckus and Drenn.

The goal of this hack is to update the orignal Version of Pokemon Red to make it a better experience overall without changing the core game too much.

The biggest changes are:

- all 151 Pokemon are available, no trades needed
- trade evolutions evolve by leveling up
- important TMs can be bought in Celadon City
- Moonstones are also available in Celadon City
- Charizard can learn Fly
- Cut and Flash have been changed to be desirable moves and not a burden
- Poison Type weakness to Bug Type has been fixed to be in line with later Generations and to balance the new Cut move properties
- Focus Energy has been changed to raise Attack by 1 level to side step the bug of it reducing crit rate instead of raising it
- Moltres learns Flamethrower by level up
- Scyther learns Wing Attack by level up
- new Titlescreen

Enjoy. :)