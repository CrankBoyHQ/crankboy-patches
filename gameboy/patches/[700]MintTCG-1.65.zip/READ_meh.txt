Pokemon Trading Card Game: Mint's Adventure
V1.65
25 OCT 2021

-Nikc

Hey there! If you've played Pokemon GB2, you've been introduced to Mint, the female protagonist of the series. The game acts like she beat the Grand Masters; however, she's nowhere to be found in the first installment. This graphic, palette and text hack fixes that, so Mint can have her time to shine.

v1.65 (25 OCT 2021)
------------
*Fixed a reference to "he" -> "she" when someone is talking about you winning the Legendary Pokemon Cards
*Fixed a reference to "his" -> "her" cards when you give all your Energy cards to a member of the Fire Club
*Fixed a reference to "he" -> "she" when Ronald tries to prevent you from challenging them for the Legenard Pokemon Cards

(Thanks to yukimayari for catching those!)

v1.50 (31 AUG 2020)
------------
*Fixed a reference to "him" -> "her" when Dr. Mason tells Sam to duel you (Thanks to Steven Reich for catching that!)

v1.25 (29 DEC 2010)
------------
*Hex-edited the default name to 'MINT' the RIGHT way (before, I had just moved some tiles around)
*Altered some dialog that referred to the player as male.
*Checksum fixed.

v1.0
------------
*Player sprite modified to match the GB2 Mint sprite, and switched from red to blue.
*Player portrait changed to Mint's, and recolored to fit the GB1 palette.
*Default name changed to 'MINT' - via editing graphics, haha.

**************
Possible Future Updates?
*Fix any text mistakes...
**************

How to patch:
Get a copy of the Pokemon TCG 1 ROM, this patch, and an IPS patching program (Lunar IPS seems to be the standard).
Run the program, click 'Apply patch', and viola! Enjoy.

(Tools used by me)
TileLayer Pro
VisualBoy Advanced
GBSUM
XVI32
Lunar IPS
Ucon64


Questions? Suggestions? Glitches?
WonderswanTranslations@gmail.com

