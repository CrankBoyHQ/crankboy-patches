- Dragon Quest III adjustment -

"DQ III adjust.ips"

Apply this patch to GBC ROM "Dragon Quest III".

[Changes]
- Improved graphics for female party characters
- Adjustment of equipping by occupation
- MP consumption halved
- Slightly weaken monsters other than boss characters
- Increase in experience points and money received
- Encounter rate reduced by 20%

Note)
Use it after understanding that it will be a slightly easier game.

"Female Hero IV.ips"

Apply after applying "DQ III adjust.ips" to change the female hero to IV style.
