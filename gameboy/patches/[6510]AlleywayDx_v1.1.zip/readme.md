A big overhaul of Alleyway for the gameboy.

Adding colors, fixes and improvements.

This hack includes:

* All Levels have custom colors
* Select starting stage with a/b buttons on title screen
* Change between blueish or white background with select button on title screen 
* Scores can now show 5 digits, and max score is now 65535
* High score saving
* Mario head for lives looks nicer
* Fixed bug from original game where if you die as a small paddle on the far right, your next paddle started stuck in the wall
* Still plays ok on DMG
* Demo takes twice as long before it starts, so there is more time to select start level
* Fixed a bug that froze the game when running on MGBA core in Retroarch

2022/01/15 v1.0
2023/04/06 v1.1
