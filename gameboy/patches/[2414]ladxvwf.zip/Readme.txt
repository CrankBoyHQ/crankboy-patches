THE LEGEND OF ZELDA: LINK'S AWAKENING DX - VWF EDITION
------------------------------------------------------
Version 1.0 - May 19 2015                    by toruzz


SO WHAT IS THIS, EXACTLY?
-------------------------
This patch drastically improves the readability of the
text by introducing a really sexy VWF (Variable Width
Font) into the game. It also fixes a couple of typos
and removes the spaces at the end of the player's name
(if any).


HOW DO I APPLY THIS PATCH?
--------------------------
You'll need to use an IPS patching program like
Lunar IPS to apply it on Link's Awakening DX v1.2
English ROM.


WOULD IT WORK ON REAL HARDWARE?
-------------------------------
I didn't make the patch to be compatible with real
hardware, so I don't know. Use it at your own risk.


I FOUND A TYPO OR A BUG
-----------------------
Please, contact me at toruzz@gmail.com and provide a
screenshot so I can fix it.


THERE IS SOMETHING I DON'T LIKE
-------------------------------
You can go to the thread on romhacking.net and tell
me about it, but I probably won't care.


SPECIAL THANKS
--------------
JuananBow for a super-fast betatesting!


DISCLAIMER
----------
I'm NOT responsible for the use of the program and/or
the information distributed. Use it at your own risk.
I'm NOT affiliated nor endorsed by Nintendo.
Registered trademarks are of their respective owners.

DO NOT DISTRIBUTE THE PATCH WITHOUT THIS README