Welcome to Donkey Kong: SUMMER
~ ~ ~
Created by: CousinCatnip
Additional Modding by: Menblock
Level Ideas by: Birdieboogie, Nickyfive, Menblock, FakeMegaRobDad, OmegawyvernGaming, C0inpusher, HumblyMumbly, Kujakiller, ProdigyRTA, Christianapollo and Eberkk

How to Patch:
-You need Donkey Kong.gb (Japan, USA) and your favourite IPS patcher to apply the patch.
-Do not use the (World) version as a base
-You can also patch it online on romhacking.net.
It works on real hardware or emulators, try it with the SGB2!

What to expect?
-Over 25 NEW Levels made by the CousinCatnip community
-Infinite Lives so you can retry forever
-Trying to get 100% and dominate the 1-up High Score

The History:
During the Summer months, CousinCatnip does a fun little stream marathon called: The Summer of DK & Banjo! 
To celebrate the 2022 season, they wanted to do something fresh so they asked their community for level ideas and almost the entire hack was built on stream. 
Why THIS game? They saw there was a fantastic level editor for DK'94 but very few hacks that used it! So now here we are...

Known Issues:
-Map Screen puts the X in the wrong spot sometimes but doesn't affect gameplay.
-Some cutscenes have very minor garbled graphics, not sure why.
-Stage 2-10 has a softlock if you roll off the placeable block onto the dissolving sand. You can save and quit but will have to redo the previous level.

Thank you for playing!
~ ~ ~