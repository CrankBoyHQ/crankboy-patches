This is my first ROM Hack :D

Please use LIPS to patch your ROM, this patch works with both Mega Man IV (USA) and Rockman World 4 (JPN)

Changelog:
	Fixed Pharaoh Man Shading
	Fixed Crystal Man Shading
	Fixed Charge Man Shading
	Fixed Stone Man Floor Shading
	Fixed Item Graphics Shading

Patch created by Rabbid4240
https://twitter.com/Rabbid4240