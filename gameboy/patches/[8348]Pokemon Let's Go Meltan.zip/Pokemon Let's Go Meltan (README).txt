Pokemon Let's Meltan is a romhack of pokemon blue, made using pret, created by melzinoff

menu and overworld sprites by LuigiTKO,

Use IPS Patcher to a Pokemon Blue Rom and you're good to go

It features:
- All Alolan forms (trade in every pkmn center or can be found in the wild)
- Meltan as an encounter on the SS Anne
- Melmetal as an encounter in the Pokemon Mansion
- The SS Anne doesn't leave anymore
- Mew is a Static Encounter on Faraway island, unlocked by showing Mr Briney the Faraway Island Map.
- The Steel, Dark and Fairy type added with moves to go with.
- Some moves have been added to buff poison types.
- Ghost is super effective to psychic and Shadowball has been added as a move to the ghost types movetsets of the romhack.
- BugBuzz and Dragon Pulse have been added to dragon and bug types movesets.
- Most pokemons have menu icons.