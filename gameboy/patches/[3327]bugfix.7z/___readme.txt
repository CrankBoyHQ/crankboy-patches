Wizardry Empire - Fukkatsu no Tsue (Japan)


Version: 0.2




Minor bugfixes for original Japan game:
- Computes correct box height for dungeon dialogs.

- Combat text inserts newlines based on number/name lengths.

- 1 problem dialog box now closes.

- Yes/No cursor moves up/down properly on some bugged dialogs.

- Kunoichi spells (Kasumi Giri and Ikadzuchi) show critical hit messages.






Update 0.2
- Readme updated.





Original Japan game can be used with:
- Bug fixes 0.1+
- Ghoul uncensor 0.2+

Can be applied in any order.






Not compatible:
- English translation  (fixes already included)
