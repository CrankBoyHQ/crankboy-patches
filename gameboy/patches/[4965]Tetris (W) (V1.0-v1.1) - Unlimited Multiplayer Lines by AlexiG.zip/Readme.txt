Tetris (World) (V1.0/v1.1) - Unlimited Multiplayer Lines Patch by AlexiG
------------------------------------------------------------------------

The original Tetris for the Game Boy when played in multiplayer mode had a limit of 30 lines.

With this patch you have an unlimited number of lines, the counter will stay at 30.

There is a patch for Tetris (World) v1.0 and v1.1.