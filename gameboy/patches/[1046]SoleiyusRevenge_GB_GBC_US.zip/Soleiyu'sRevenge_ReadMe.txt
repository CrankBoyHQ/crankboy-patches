Soleiyu's Revenge

Hackers: Serio and Sliver X

This hack lets you play as Soleiyu Belmont, one of the final bosses and the son of Christopher Belmont. There are two patches: Soleiyu'sRevenge_GB_US and Soleiyu'sRevenge_GBC_KonamiGBCollectionVol.3_EU. The Soleiyu'sRevenge_GB_US patch is for the US version of CVII:BR while the Soleiyu'sRevenge_GBC_KonamiGBCollectionVol.3_EU patch is for the EU game called Konami GB Collection Volume 3 which has CVII:BR on it in colorized form. Apply both accordingly.