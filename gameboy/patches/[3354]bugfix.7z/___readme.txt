Wizardry Empire - Rev A (Japan)


Version: 0.1




Minor bugfixes for original Japan game:
- Combat text inserts newlines based on length of numbers, names
  (incorrectly used max line width before)

- Special classes can cast spells in combat
  (didn't work when mage / priest spellbooks were empty)






Not compatible:
- English translation  (fixes already included)
