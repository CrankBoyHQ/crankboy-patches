Find out why everybody’s calling on Dr. Garfield.

(This may sting a little.)

Looking for an intense new challenge?
Dr. Garfield is here and he's got the cure! 

Three kinds of ugly, nasty viruses are on the loose. But these germs are fun to catch. Garfield throws multi-colored vitamin capsules into the bottle. You can move, shift or spin the capsules as they fall. Arrange them to align with other capsules on top of the virus. If you can get 4 or more of the same color in a row, POOF! The viruses disappear! Destroy all the viruses in the bottle and you progress to the next round, where things get even more difficult. Play alone or enjoy simultaneous 2-player action, only from Nintendo on your Nintendo Entertainment System or Nintendo Game Boy.

Dr. Garfield—the fun is contagious!

Garfield and Garfield characters © 1978, 1990 King Feature Syndicate, Paws Incorporated.
Dr. Garfield © 1990 Nintendo
Nintendo of America Inc., P.O. Box 957, Redmond, WA 98073-0957, 1-800-633-3236, Fax: 206/882-3585

IPS Patches are provided for either of these ROMs:

Dr. Mario (World) (Rev 1)
Dr. Mario (World)

Available as Game Boy Color (GBC) files, or GBW (Game Boy black and white).

A total of four patches are therefore available.

From Pangent Technologies.

This is based off of the Dr. Mario DX Game Boy hack by marc_max and Da_GPer.

Some thanks to FAST6191.

Also available for NES:
https://www.youtube.com/watch?v=AkqfMeMGDww