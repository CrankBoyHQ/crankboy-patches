This is a complete reworking of Game Boy Tetris into an original game called "Threetris". This is similar to the version released for NES last year. The pieces have been refined even more and it ends up being very fun.

All game modes, even 2 player, have been tested.

This mod is for the more common 1.1 version of Gameboy Tetris.

-

There are 3 additional patches for converting other mods to Threetris.

"Threetris - Cleaner Graphics" is a port of thirtythree's Cleaner Graphics mod. (You can use this on a default 1.1 Gambeboy Tetris OR on an already patched Tetris - Cleaner Graphics.)

"Threetris - Classic Hard Drop" is specifically for Ospin's Classic Hard Drop mod. (Use this patch second, on the already patched Tetris - Hard Drop.)

"Threetris - Rosy Retrospection" is specifically for Ospin's awesome mod. (Use this patch second, on the already patched Tetris - Rosy Retrospection.) [The ability to Pause had to be disabled because of the routine Ospin uses relative to how Start & Select work with the HOLD feature. That routine was failing during pause because of the Threetris piece shapes, so pause was simply disabled. Disabling pause makes everything still work perfectly. You should still be able to pause using whatever device you are playing this on, except for original hardware.]
