Presenting more Tetris fun! The default Super Game Boy palette for Tetris Attack was very bland and while it technically does work for the game, it could have been better. I created a new palette that looks closer to the SNES version of the game with a few bells and whistles. The new palette patch also works with the Japanese version, Yoshi no Panelpon without issues.

I also uploaded a video showing the new SGB palette: https://youtu.be/DOHfolpAhXM

Please consider supporting my past, present and future projects at patreon.com/nensondubois.

Stay tuend for several more game modifications. :)

eof