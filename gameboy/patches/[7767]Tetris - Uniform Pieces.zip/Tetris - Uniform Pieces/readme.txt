- Tetris (Game Boy) - Uniform Pieces by Snessy -

This hack makes every piece use the same design, like most newer Tetris games.
Useful if you find the original designs distracting or if you just want a different look for the game.

Two patches are included:

"Uniform Pieces (Original).bps" is for the original (1.1) version of the game.
"Uniform Pieces (Rosy Retrospection).bps" is for Ospin's Rosy Retrospection hack (https://www.romhacking.net/hacks/5813/)
Be sure to apply the Rosy Retrospection hack BEFORE this patch.

Enjoy!

Fun fact: The pieces' designs here are specifically inspired by the ones from Tetris 2 + Bombliss on the Famicom.