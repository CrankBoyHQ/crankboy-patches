"Tetris - Beginner" is exactly what it sounds like... Tetris for beginners! This is perfect for anyone who is perhaps showing their young kid Tetris for the first time. Or maybe for someone who just wants to relax!

Those two annoying zig-zag shapes (Z & S) that have been plaguing our Tetris games for years? GONE! To ensure that the loss of those two shapes did not make the actual gameplay less enjoyable, the frequency of the T shape has been increased. The frequency of the line shape has also been increased because, hey, this is Tetris for beginners! These changes make a perfect "easy mode" of Gameboy Tetris.

All game modes, even 2 player, have been tested.

This mod is for the more common 1.1 version of Gameboy Tetris.

-

This patch can also be used with thirtythree's Cleaner Graphics mod and potentially other mods. (Use this patch first and then use the other patch.)

"Tetris - Beginner - Classic Hard Drop" is specifically for Ospin's Classic Hard Drop mod. (Use this patch second, on the already patched Tetris - Classic Hard Drop.)

"Tetris - Beginner - Rosy Retrospection" is specifically for Ospin's awesome mod. (Use this patch second, on the already patched Rosy Retrospection.)

-

Version 1.1 (There was a small compatibility issue with Ospin’s Classic Hard Drop mod. That has been fixed.)