Castlevania - The Adventure (USA)
CRC32: 216E6AA1

Konami GB Collection Vol. 1 (Europe)
CRC32: 203F8727

Patch Version: 1.0

This is essentially the speed and whip hack from hiro1112 WITHOUT any graphical changes. I also stripped the graphical changes from the color version of the game contained in the Konami GB Collection Vol. 1.

- Increased character speed
- No whip downgrade when being hit by an enemy

Credits to hiro1112 and Ugetab.
