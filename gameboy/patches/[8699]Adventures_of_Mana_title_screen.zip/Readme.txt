Use Lunar IPS to patch the USA version of Final Fantasy Adventure.

Always use these patch files on the original english game. Don't try to use any on a game that's already been patched. If you do, it might work, but might not.

AM I MAKING A PATCH THAT CHANGES THE DX VERSION'S TITLE SCREEN???
Yes. But at the moment I need more info from the creator of the colorization hack to finish it properly. It's misaligned and incorrectly colored currently.

This patch's source code on github: https://github.com/Vortyne/FFA-Disassembly-Adventures-of-Mana

