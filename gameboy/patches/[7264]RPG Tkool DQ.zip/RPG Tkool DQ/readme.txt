- RPG Tkool DQ -

"RPG Tkool DQ.ips"

This is an IPS patch for the "RPG Tsukuru GB".

[Changes]
- Title screen
- Monster graphics
- Party characters
- Map graphics

Changed the graphics to Dragon Quest. (Monsters and walking characters)
Some map graphics were changed. (Paintings, trees, dungeons, etc)
In addition, four types of castles graphics were ported from RPG Tukuru GB2.

It's not good enough due to lack of technology, but someday a master will brush it up.

This patch can be used in conjunction with the following translation patches.

https://www.romhacking.net/translations/42/

<EOF>