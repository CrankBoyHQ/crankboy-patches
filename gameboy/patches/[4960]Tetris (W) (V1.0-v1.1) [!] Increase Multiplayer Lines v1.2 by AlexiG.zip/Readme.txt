Tetris (World) (V1.0/v1.1) - Increase Multiplayer Lines Patch by AlexiG
-----------------------------------------------------------------------

The original Tetris for Game Boy when played in multiplayer mode had a limit of 30 lines.

With this patch you have FF lines instead of 30.

There is a patch for Tetris (World) v1.0 and v1.1.