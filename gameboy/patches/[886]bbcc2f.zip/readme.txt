The Ultimate Bugs Bunny Crazy Castle Two Two, � Frank Maggiore, 2012

Version 1.3

The Bugs Bunny Crazy Castle II hack, Game Boy

Created January 23, 2012
Updated January 25, 2012:  Fixed flow of Stage 9
        January 26, 2012:  Fixed enemy priority lists
        January 29, 2012:  Fixing enemy priority lists caused a
                           misplaced Wile E. Coyote in Stage 9, fixed
        January 30, 2012:  Fixed major bug that appeared in Stage 5,
                           and made a few levels a bit easier.  Hope
                           everything is finally fixed =P

Contact:  golden_road15@hotmail.com
Site:  http://www.angelfire.com/la3/goldenroad15/hacks.html