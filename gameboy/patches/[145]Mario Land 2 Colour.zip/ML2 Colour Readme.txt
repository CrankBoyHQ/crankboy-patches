I downloaded the patch from rom hacking the fixed the bug that caused the tiles to poop out after you clear a stage or die.

- Drakon The_Domo@hotmail.com -