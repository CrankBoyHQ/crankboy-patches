Revelations_-_The_Demon_Slayer Improvement

For those who don't know Revelations_-_The_Demon_Slayer is the First Last Bible Megami Tensei Gaiden - Last Bible 
only in English, a lot of the Character graphics where replaced and changed from the original Gameboy Version, 
most of those have now been restored. And it will look more like a Last Bible Game then it did before once you apply 
this patch. The Main Character is now a warrior instead of a rip off of what was originally Terry from Dragon Warrior 
Monsters. In Last Bible the starting Character was a Female Warrior but Nintendo didn't want that. 
And as this is an improvement of Revelations The Demon Slayer that part wasn't restored. 
I call this an Improvement though it doesn't look great, from the actual Game in looks much better.

Note: This must be patched over Revelations_-_The_Demon_Slayer_(U)_[C][!].gbc 
and not Megami Tensei Gaiden - Last Bible (J) [M][!].gb

Use LunarIPS and don't ask where to get roms. Enjoy.


