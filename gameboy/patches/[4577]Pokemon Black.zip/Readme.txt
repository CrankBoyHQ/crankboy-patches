Intro:

This hack recreates the game based on the famous pokemon black creepypasta as close as possible to the original story.

Read the story here:
https://tinycartridge.com/post/866743831/super-creepy-pok%C3%A9mon-hack

Features:

This game is complete, and every feature from the creepypasta is implemented.

Thanks to:

*. triumph (from Skeetendo), who pointed out many things that I haven't noticed, and for testing
*. Reidd, for the sprites and for his work on his recreation of pokemon black
*. Pokemon Red disassembly, without it this project wouldn't have been possible

I recommend using an accurate emulator like BGB, Gambatte, SameBoy or BizHawk instead of the popular ones like VBA and VBA-M, to avoid experiencing any emulator related bugs that I missed.
