Pokemon Gold & Silver: JP Changes
V1
19 MAR 2011
-Nikc

Back in the 90s, Nintendo had a great fondness for censorship. With many games (including Pokemon), they felt it was their job to protect us from
the dangers of pixelated sex, drugs, religion, and alleged racism. Well, in case you wanna see what all the fuss was about, this patch
fixes the graphical changes made during localization.

v1
------------
*Returned the Beauty trainer's short-shorts, and let both her and the Swimmer (female) trainer wink again.
*Gave the Fisherman trainer his cigarette back (he was going through withdrawals).
*Let the Sage trainer pray again, and allowed the Medium trainer to hold her prayer beads again

*Restored the normal and Shiny versions of Jynx to their more colorful (and controversial) appearances.

**************
Possible Future Updates?
*Add any other changed content I missed.
**************

How to patch:
Get a copy of the Pokemon Gold or Silver rom, choose the correct patch for that version, and an IPS patching program (Lunar IPS seems to be the standard).
Run the program, click 'Apply patch', and viola! Enjoy.

(Tools used by me)
VisualBoy Advanced
AGIxp
Lunar IPS
Bulbapedia (To find out what changes were made)


Questions? Glitches? Other JP->EN changes you know about?
nikcdc@gmail.com
nikcdc.110mb.com

