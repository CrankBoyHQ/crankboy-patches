####################################################
#             = Final Fantasy Legend =             #
#         = Makaitoushi Sa-Ga Title Hack =         #
####################################################
	by Joe Buck
	  AKA Killa B
	  AKA GenoBlast


####################################################
#                   = Notes =                      #
####################################################

    This patch is for The Final Fantasy Legend.
To apply this patch you will need a Final Fantasy
Legend (U) rom (which I will not supply) and an IPS
Patcher, such as Lunar IPS. You can get Lunar IPS
from http://www.romhacking.net. I am not responsible
for any damages caused to you or your hard drive
when trying to apply this patch. Of course, nothing
bad should happen unless you're a dumbass.

####################################################
#               = Special Thanks =                 #
####################################################

    Special thanks to the following people:
	-Squaresoft for making FFL.
	-Nintendo for publishing FFL.
	-Griffin Knodle for making Relative Searcher
	-Brian Bennewitz for making Translhextion
	-Kent Hansen for making Tile Layer Pro
	-FuSoYa for making Lunar IPS
	-Other people I forgot...
	-And everybody at the RHDN forums!

�Killa B�
04/14/2007
xGenoBlast@gmail.com