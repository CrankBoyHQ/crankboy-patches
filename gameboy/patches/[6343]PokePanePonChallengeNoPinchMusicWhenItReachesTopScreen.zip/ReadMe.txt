Patch created by StarkMan8172

Game: Pokémon de PanePon (GBC) / Pokémon Puzzle Challenge (GBC)
Patch: No more pinch music when Panels reach the top of the screen

This patch simply prevents the pinch theme from playing when the Panels reach the top of the screen. This is especially useful as the majority of stages uses the same pinch theme meaning that it can get repetitive after a long play session. Also applies to the Hidden Panel de Pon GB game.

Note: Tested the patch on the Europe, Japanese and US version and they all they can use the same patch as the location for the routines that were altered are the same.

Rom Info:
Database match: Pokemon de Panepon (Japan)
Database: No-Intro: Game Boy/Color (v. 20210227-015730)
File/ROM SHA-1: 110AE6649B4264F88D82760AD6AE4EE7F07DB9B2
File/ROM CRC32: 6BF7E4A6

Database match: Pokemon Puzzle Challenge (Europe) (En,Fr,De,Es,It)
Database: No-Intro: Game Boy/Color (v. 20210227-015730)
File/ROM SHA-1: E40D6A7F78B449E5A55BAAAEA7E227AB19D510E4
File/ROM CRC32: 8206B1CE

Database match: Pokemon Puzzle Challenge (USA, Australia)
Database: No-Intro: Game Boy/Color (v. 20210227-015730)
File/ROM SHA-1: BBF952412250AE511B3B862566E424CE6A672F99
File/ROM CRC32: D06BBA96