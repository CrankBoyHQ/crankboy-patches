Patch created by StarkMan8172

Game: Yoshi no Panepon (GB) / Tetris Attack (GB)
Patch: No more pinch music when Panels reach the top of the screen

This patch simply prevents the pinch music from playing when the Panels reach the top of the screen. This is especially more useful when you want to hear songs
that are different in the later parts compared to their 16-bit counterpart.

Note: The reason there is a patch for both REV1 and JP is because the location that is patched are the same for both the roms. The non-REV1 version for the US/EU rom however, has its own location, hence there's a separate patch.

Rom Info:
Database match: Yoshi no Panepon (Japan) (SGB Enhanced)
Database: No-Intro: Game Boy/Color (v. 20210227-015730)
File/ROM SHA-1: C54D0A33A562C93B9E1243FD9C615B5F92671E58
File/ROM CRC32: 3BEB7239

Database match: Tetris Attack (USA) (SGB Enhanced)
Database: No-Intro: Game Boy/Color (v. 20210227-015730)
File/ROM SHA-1: 3DE8D7F30322BC50008AB0D917ACD0A934B5B195
File/ROM CRC32: B76C769B

Database match: Tetris Attack (USA, Europe) (Rev 1) (SGB Enhanced)
Database: No-Intro: Game Boy/Color (v. 20210227-015730)
File/ROM SHA-1: 85B4B0D5A5A0417E10FED853419FE65975A6071F
File/ROM CRC32: 5EE45A4D
