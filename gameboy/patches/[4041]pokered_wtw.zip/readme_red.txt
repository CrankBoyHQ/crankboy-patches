This patch allows the player to run and walk through walls while the B button is held down.
On top of that, it also tries to replicate the anti-crash measure that the Spaceworld 97 demos use for
their debug-mode walk through walls code.
When entering the void, which would normally crash the game, the player will simply get thrown back into the map.


Patch to "Pokemon - Red Version (USA, Europe).gb"

MD5:		3d45c1ee9abd5738df46d2bdda8b57dc
SHA1:		ea9bcae617fdf159b045185467ae58b2e4a48b9a
SHA-256:	5ca7ba01642a3b27b0cc0b5349b52792795b62d3ed977e98a09390659af96b7b