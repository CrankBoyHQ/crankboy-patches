Oracle of Ages: VWF Edition v1.0

Author: Drenn

===============================================================================
ABOUT
===============================================================================

This is a ROM hack of The Legend of Zelda: Oracle of Ages for the Gameboy which
replaces the game's fixed-width font with a variable-width one.

The source code for this hack is available in the "vwf" branch in the following
git repository: https://github.com/drenn1/ages-disasm

===============================================================================
PATCHING
===============================================================================

Apply the provided patch over a US region Oracle of Ages rom.

The patch is in xdelta format. You can use XDelta UI to apply it:
http://www.romhacking.net/utilities/598/

===============================================================================
THANKS
===============================================================================

To Toruzz who provided the font and the idea from his Link's Awakening VWF hack.
