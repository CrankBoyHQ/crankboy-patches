Amazing Penguin DX by marc_max
==================

Another DMG classic joins the DX colorization crew!

Enjoy this Natsume's little addictive gem now in full color for the first time!



Game instructions
-----------------
[B] remove seal
[A] kick black seal

Objective: open every square by removing the circles or balls next to them.
Attack: black seals can be kicked and used against enemies!
Heart bonus: Try to open two squares that contain hearts simultaneously and you will get secret a big score bonus or even a 1-UP!



Status
------
The entire game is fully colorized, however...

The credits scene (after clearing game) got just a standard sepia palette.
There are a bunch of reasons on why I decided to left it that way (mostly the original game's bad code).
It is definitively possible to colorize it, but this started as a small project and didn't feel like spending too much time on it.



Patching information
--------------------
You must provide the original Amazing Penguin ROM:
Amazing Penguin (USA, Europe)
CRC32: 3011d5ca
MD5:   d8326bfee457ccb2c0afb8dd6ac11db2
SHA1:  84cc6452823eb05ee38679aec86e3cc6e4a50e6f

Apply the patch here: https://www.romhacking.net/patch/


Patch history
-------------
v1.0 (2022-05-03) - first version
