This is a hack of Pokémon Red and Blue Version (USA, Europe) that swaps the backsprites with those found in the Pokémon Gold and Silver 1997 Space World demo. No other changes have been made to the game. The patches are as follows:

SWBS (Spaceworld Backsprites)
SWBS-ROBS (Spaceworld + larger Red/Old man backsprites)
SWBS-ROBS-CMBS (Spaceworld + larger Red/Old man + cropped Mew backsprites)
SWBS-CMBS (Spaceworld + cropped Mew backsprites)

The Mew thing was just a personal preference as I really disliked how goofy the backsprite looked. The cropped one just removes his goofy looking legs.

Credit:
Team Spaceworld (documenting and disassembling pokegold-spaceworld)
Danny-E 33 (code to allow larger back sprites)
Poketto (custom Red backsprite)
SteppoBlazer (custom Old Man backsprite)
