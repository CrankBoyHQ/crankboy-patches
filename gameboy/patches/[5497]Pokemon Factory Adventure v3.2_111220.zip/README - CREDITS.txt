Pokemon Factory Adventure - a hack by Cam

Credits:
External Developers:
*TShadowKnight & Co. - Creating the original Roaming Red that this is codebased on (https://www.pokecommunity.com/showthread.php?t=403522)
*TPP Devs - Battle Tent from Anniversary Red
*Luna - Some bugfix code used from Red++

Addtional Game & Art work:
*luckytyphlosion, Rangi, Pfero - ASM & decomp assistance
*Quent, TurboSpurdo, TC, PolandDev - additional writing & suggestions
*Rool, TC, and a fren :) - additional art
*Ahab's Art (https://twitter.com/ahabsartwork) - Box promo art

Source Images & Content:
*jdonald - the original PF archive (https://www.ocf.berkeley.edu/~jdonald/pokemon/factory/)
*Kaiser233 on deviantart - additional 90s fakemon archival source images (https://www.deviantart.com/kaiser233/gallery)