Dai-2-Ji Super Robot Taisen G Hack

"SRW2G_Hack.ips"

This is the IPS patch for the "Dai-2-Ji Super Robot Taisen G" for GAME BOY.

The League Militaire, a private military organization, has sent a unique Kamonegi team instead of the Shrike team of the lead forces to support the White Base.
Leading the all-female team, like Shrike team, are veterans and former federal troops Kayra and Harrison.
Let's see what will happen now...

The Shrike team is attractive, but the Kamonegi team is no less so.;)

[Changes]
- Renewed members of the Shrike Team (Team name has also changed)
- Faces of general soldiers, Yazan, Lila, and Sarah
 (* The text has changed due to the above changes)
- SP consumption 1/5, unit and weapon modification costs 1/10
- Swap repair costs and earned funds (increased earned funds)
- Lowered the HP of units with HP over 15000.
- Fin funnel enhancement (Nu Gundam)
- Renovation of Boss and Borot
 + Borot is possible to change pilot.
 + Pilot ability adjustment, Spilit command change, Borot strengthening.
- Strengthening for V Gundam, Gun EZ, and Gun Blaster
- Mazinger Z, Minerva X, Grendizer, Getter Queen, Texas Mac, Mecha Kochouki
 + Enhanced performance, and made it possible to change pilot with the Mazinger series.
- Medea and White Ark modified to mother ship attributes
- Enhanced the following weapons:
Hyper Hammer, Photon Missile, Mazinger Blade, Double Harken, Getter Tomahawk, Tomahawk Boomerang, Double Tomahawk, Double Tomahawk Boomerang, Hyper Beam Saber, Double Beam Rifle, Butterfly Dance, Boomerang, Arm Beam Gun

Super Borot Punch stretches his arm and hits the opponent who is a little ahead.
In addition, Special DX Borot Punch makes a big jump and hits in the air.
Both consume EN, but if they hit, they are weapons that cause miraculous damage.
Please take advantage of Boss and Bolot that were unnecessary levels.

The following is a patch that changes only the cost aspect.

"SRW2G_Eco.ips"

The following patch increases the ability of allied pilots by 3-8% and changes only the images of Amuro and Bright.

"SRW2G_Pilot.ips"

The following patch is included in its entirety and applies all of the above changes.

"SRW2G_Hack.ips"

<EOF>