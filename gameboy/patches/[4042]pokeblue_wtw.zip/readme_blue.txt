This patch allows the player to run and walk through walls while the B button is held down.
On top of that, it also tries to replicate the anti-crash measure that the Spaceworld 97 demos use for
their debug-mode walk through walls code.
When entering the void, which would normally crash the game, the player will simply get thrown back into the map.


Patch to "Pokemon - Blue Version (USA, Europe).gb"

MD5:		50927e843568814f7ed45ec4f944bd8b
SHA1:		d7037c83e1ae5b39bde3c30787637ba1d4c48ce2
SHA-256:	2a951313c2640e8c2cb21f25d1db019ae6245d9c7121f754fa61afd7bee6452d