"Tetris - Cleaner Graphics" is an updated graphics pack for Gameboy Tetris.  The graphics have all been improved with a much cleaner look.   The individual pieces, the statistics area, and the background have all been touched up in one way or another.

All game modes, even 2 player, have been edited and tested.

No gameplay changes have been made whatsoever.

This mod is for the more common 1.1 version of Gameboy Tetris.


There are 2 additional patches included:

“Tetris - Cleaner Graphics - Pieces Only” is for anyone who only wants the graphics changed on the pieces.  This patch can also be used for Ospin’s Classic Harddrop mod and potentially other mods.  (Use this patch FIRST and then use the Harddrop patch.)

“Tetris - Cleaner Graphics - Pieces Only - Rosy Retrospection” is specifically for Ospin’s awesome mod.  (Use this patch SECOND, on the already patched Rosy Retrospection.)