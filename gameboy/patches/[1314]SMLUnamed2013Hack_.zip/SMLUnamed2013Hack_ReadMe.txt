Unnamed 2013 Super Mario Land Hack

Created by Arne Niklas Jansson

This hack changes the graphics in the game to be much better. Very good accomplishment considering how small the sprites are.

The included Pauline patch changes Mario into Pauline (From Donkey Kong?). The Alien Patch changes Mario into either the chest bursters from the Alien films when small, and the fully grown Alien when power-ups are collected.

Seems to work well on the 1.0 version of the game.

Official website is here:

http://androidarts.com/sml/sml.htm