Dr. Mario - Gameboy


Turns off punishment blocks when either player
creates a 2+ combo.

Works on all regions.
