"Super Daisy Land" hack, by Hypershell
released October 15th, 2008
*minor update May 28, 2011

Contents:
-This readme.
-"Super Daisy Land.ips"

Apply the IPS patch to the game rom
"Super Mario Land (JUE) (V1.0) [!].gb"

*NOTE* Some older versions of GoodGBx
(such as 2.02) have a bad dump incorrectly
labeled as [!], and it will not work either
by itself or with this patch.  The CRC32
of the correct dump is 90776841.

Play as Daisy and, with a little help
from an old friend, rescue Luigi.

Hypershell WILL NOT supply any game roms
under any circumstances, and assumes no
responsibility whatsoever for any mishaps
that may result from bone-headed use.