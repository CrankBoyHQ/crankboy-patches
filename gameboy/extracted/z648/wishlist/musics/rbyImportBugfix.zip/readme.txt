===========================================================================
| RBY Music Importer
| Version 0.5
| By Sonic65
|
| Readme
===========================================================================

RBY Music Importer is a tool to import Famitracker files (.ftm) into a Pokemon
Red/Blue/Yellow ROM. It supports importing of all 4 basic sound channels on
the NES and GB (square 1, square 2, triangle, noise), as well as both .ASM
and .BIN export (and a quick inject feature for .BINs into RBY ROMs).

It doesn't support effects or any other file formats yet, however.

A sample song to import is included: route202.ftm. It's a NES demake of the Route 202 theme from Pokemon Diamond/Pearl. Have fun with that.